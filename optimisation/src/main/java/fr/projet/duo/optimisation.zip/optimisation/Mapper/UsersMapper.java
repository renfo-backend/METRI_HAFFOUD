package fr.projet.duo.optimisation.Mapper;

import fr.projet.duo.optimisation.DTO.UsersDTO;
import fr.projet.duo.optimisation.Entity.Users;
import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper(componentModel = "spring")
public interface UsersMapper {

    UsersMapper INSTANCE = Mappers.getMapper(UsersMapper.class);

    @Mapping(target = "notifications", ignore = true) // Ignorer pour éviter la récursion
    UsersDTO usersToUsersDTO(Users users);

    Users UsersDTOToUsers(UsersDTO usersDTO);

    @Mapping(target = "notifications", ignore = true) // Ignorer pour éviter la récursion
    List<UsersDTO> usersToUsersDTO(List<Users> users);

    List<Users> UsersDTOToUsers(List<UsersDTO> usersDTO);
}
package fr.projet.duo.optimisation.Mapper;

import fr.projet.duo.optimisation.DTO.MessageDTO;
import fr.projet.duo.optimisation.Entity.Message;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper(componentModel = "spring")
public interface MessageMapper {

    MessageMapper INSTANCE = Mappers.getMapper(MessageMapper.class);

    @Mapping(target = "party.messages", ignore = true) // Pour éviter la récursion entre Message et Party
    @Mapping(target = "users.notifications", ignore = true) // Pour éviter la récursion entre Message et Users
    MessageDTO toDTO(Message message);

    List<MessageDTO> toDTOs(List<Message> messages);

    @Mapping(target = "party.messages", ignore = true) // Pour éviter la récursion entre Message et Party
    @Mapping(target = "users.notifications", ignore = true) // Pour éviter la récursion entre Message et Users
    Message toEntity(MessageDTO messageDTO);

    List<Message> toEntities(List<MessageDTO> messageDTOs);
}
